<?php

namespace App\Http\Controllers;
use App\User; 
use Illuminate\Http\Request;

class UserController extends Controller
{
   public function register ( Request $request)
    {
            //first validate
            $data = $request->validate([
                'username'=>'required|max:55',
                'pseudo'=>'required|max:55',
                'email'=>'email|required',
                'password'=>'required'
            ]);

            
            $data['password'] = bcrypt($request->password);
            /*Verification si l'utilisateur n'existe pas*/
            if(!$verification = User::checkIfExist($request->email)){
                $user = User::create($data);
                return response()->json(['user'=> $user]);
            }else{
                //utilisateur existe deja.
                return 'utilisateur existe';
            }
           
             
          // $accessToken = $user->createToken('authToken')->accessToken;        
    
    }

    public function login (Request $request) {
        $login = $request->validate([
            'email'=>'email|required',
            'password'=>'required'
        ]);

        if(auth()->attempt($login)) {
            return response(['message'=>'ok']);
        }else {
            return response(['message'=>'Invalid Credentials']);
        }

        $accessToken = auth()->$user->createToken('authToken')->accessToken;

        return response(['user'=> auth()->$user, 'Token'=> $accessToken]);

    }

    public function delete(Request $request, $id)

    {
        $user = User::where('id',$id);
        $user->delete();
        return response([
            'message'=>'ok',
            ]);
    }

    public function update(Request $request, $id)
    {
        $user = User::find($id);
        $user->username = $request->input('username');
        $user->pseudo = $request->input('pseudo');
        $user->email = $request->input('email');
        $user->password = $request->input('password');

        $user->save();
        return response()->json([
            'message' => 'update successfully'
        ]);

    }
}